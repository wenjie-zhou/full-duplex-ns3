#!/usr/bin/env bash


function run {
  if [[ -d $folder ]]
  then
    for file in `ls $folder`
    do
	echo "new file "$folder/$file 
        mv $folder/$file $folder/"full-"$file
      
    done
  fi
}


folder='helper'
run


